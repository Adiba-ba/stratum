#!/usr/bin/env python
"""Generate a self-contained HTML progress report for Project STRATUM.

Reuses the Step 8 corridor runner: loads the real ERA5 analysis file
``era5_del_bom_20250101.nc``, synthesizes the 25-waypoint VIDP -> VABB
FL350 flight profile, trains the calibrated LightGBM baseline, evaluates
the corridor with :func:`stratum.pipeline.runner.evaluate_corridor_flight`,
and renders the results as a standalone HTML document
(``stratum_model_progress.html``) with status badges, KPI cards, the ATC
dispatcher advisory, and the full segment-by-segment corridor table.

Exit code is 0 when the report is written.
"""

from __future__ import annotations

import html
import importlib.util
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from stratum.pipeline.runner import evaluate_corridor_flight  # noqa: E402
from stratum.routes.corridor import AIRPORTS, great_circle_waypoints  # noqa: E402

HTML_FILENAME = "stratum_model_progress.html"
PASSING_TESTS = 120
PERSISTENT_THRESHOLD = 0.50


def _load_flight_script() -> Any:
    """Import ``scripts/run_flight_corridor.py`` as a module."""
    script_path = Path(__file__).resolve().with_name("run_flight_corridor.py")
    module_name = "stratum_flight_corridor"
    spec = importlib.util.spec_from_file_location(module_name, script_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {script_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _status_badge(segment: dict[str, Any]) -> tuple[str, str]:
    """Map a segment to its contrail status badge (label, CSS class)."""
    if segment["sac_forms"] and segment["p_persist"] >= PERSISTENT_THRESHOLD:
        return "Persistent", "badge-persistent"
    if segment["sac_forms"]:
        return "Aerodynamic", "badge-aerodynamic"
    return "Clear", "badge-clear"


def _decision_text(segment: dict[str, Any]) -> str:
    """Human-readable optimization decision cell text."""
    status = segment["decision_status"]
    if status == "eligible":
        return f"Eligible &#8594; FL{segment['recommended_fl']:.0f}"
    if status == "no_robust_candidate":
        return "No robust candidate"
    if status == "abstain":
        return "Abstain (below threshold)"
    return "&#8212;"


def _render_html(
    *,
    origin: str,
    destination: str,
    departure: pd.Timestamp,
    ist_departure: pd.Timestamp,
    cruise_fl: float,
    num_waypoints: int,
    source_label: str,
    scan_mean_rhi: float,
    scan_hours: int,
    metrics: dict[str, Any],
    result: dict[str, Any],
    aircraft_type: str,
    callsign: str,
    icao24: str,
) -> str:
    """Render the standalone HTML report."""
    origin_lat, origin_lon = AIRPORTS[origin]
    destination_lat, destination_lon = AIRPORTS[destination]
    brier_raw = float(metrics["brier_raw"])
    brier_calibrated = float(metrics["brier_calibrated"])
    brier_improvement = 100.0 * (brier_raw - brier_calibrated) / brier_raw
    reroutes = result["recommended_reroutes"]
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    if reroutes:
        primary = reroutes[0]
        advisory_body = f"""
        <div class="advisory-grid">
          <div class="advisory-item">
            <div class="advisory-label">Recommended level</div>
            <div class="advisory-value">FL{primary['recommended_fl']:.0f}</div>
            <div class="advisory-sub">{html.escape(primary['direction'])} from FL{primary['baseline_fl']:.0f}</div>
          </div>
          <div class="advisory-item">
            <div class="advisory-label">Fuel penalty</div>
            <div class="advisory-value">+{primary['delta_fuel_kg']:.2f} kg</div>
            <div class="advisory-sub">+{primary['delta_co2_kg']:.2f} kg CO&#8322;</div>
          </div>
          <div class="advisory-item">
            <div class="advisory-label">Avoided warming</div>
            <div class="advisory-value">{primary['avoided_contrail_ef_j'] / 1.0e9:.2f} GJ</div>
            <div class="advisory-sub">benefit/cost {primary['benefit_to_cost_ratio']:.2e}</div>
          </div>
        </div>
        <p class="advisory-note">
          Activated at segment #{primary['segment_index'] + 1}
          ({pd.Timestamp(primary['time_utc']).strftime('%H:%M')} UTC) with
          calibrated P(persist) = {primary['p_persist']:.2f}; covers
          {primary['segments_in_event']} contiguous flagged segment(s).
          Total across {len(reroutes)} event(s): +{result['total_extra_fuel_kg']:.2f} kg fuel,
          +{result['total_extra_co2_kg']:.2f} kg CO&#8322;,
          {result['total_avoidable_warming_j'] / 1.0e9:.2f} GJ avoided warming.
        </p>
        """
    else:
        advisory_body = (
            '<p class="advisory-note">No advisories: calibrated persistence '
            "risk stayed below the 0.40 activation threshold on all segments. "
            "Flying the filed profile costs nothing extra.</p>"
        )

    rows: list[str] = []
    for segment in result["segments"]:
        label, badge_class = _status_badge(segment)
        rows.append(
            f"""
            <tr>
              <td class="num">{segment['segment_index'] + 1}</td>
              <td class="num">{pd.Timestamp(segment['time_utc']).strftime('%H:%M')}</td>
              <td class="num">{segment['lat']:.2f}</td>
              <td class="num">{segment['lon']:.2f}</td>
              <td class="num">{segment['temperature_c']:.1f}</td>
              <td class="num">{segment['rhi'] * 100.0:.0f}%</td>
              <td class="num">{segment['p_persist']:.2f}</td>
              <td><span class="badge {badge_class}">{label}</span></td>
              <td>{_decision_text(segment)}</td>
            </tr>"""
        )
    table_rows = "\n".join(rows)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Project STRATUM - Corridor Flight Report</title>
<style>
  :root {{
    --navy: #0f2440;
    --navy-soft: #1c3a5e;
    --ink: #16202e;
    --muted: #5c6b7e;
    --line: #e3e8ef;
    --surface: #f6f8fb;
    --card: #ffffff;
    --green: #0f7a55;
    --green-soft: #e3f4ec;
    --amber: #9a6200;
    --amber-soft: #fdf0d5;
    --red: #b3261e;
    --red-soft: #fbe4e2;
    --blue: #1559a6;
    --blue-soft: #e4eefb;
  }}
  * {{ box-sizing: border-box; }}
  body {{
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
      "Helvetica Neue", Arial, sans-serif;
    color: var(--ink);
    background: var(--surface);
    line-height: 1.5;
  }}
  .page {{ max-width: 1080px; margin: 0 auto; padding: 32px 24px 56px; }}
  header {{
    background: linear-gradient(135deg, var(--navy) 0%, var(--navy-soft) 100%);
    color: #ffffff;
    border-radius: 14px;
    padding: 28px 32px;
    margin-bottom: 24px;
  }}
  header h1 {{ margin: 0 0 4px; font-size: 26px; letter-spacing: 0.2px; }}
  header .subtitle {{ margin: 0 0 18px; color: #c8d6e8; font-size: 14px; }}
  .badges {{ display: flex; flex-wrap: wrap; gap: 8px; }}
  .pill {{
    display: inline-block;
    padding: 4px 11px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 600;
    background: rgba(255, 255, 255, 0.14);
    border: 1px solid rgba(255, 255, 255, 0.28);
    color: #f2f7fd;
  }}
  .pill.ok {{ background: rgba(52, 199, 138, 0.22); border-color: rgba(52, 199, 138, 0.5); }}
  section {{ margin-bottom: 28px; }}
  h2 {{
    font-size: 15px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: var(--muted);
    margin: 0 0 12px;
  }}
  .meta-grid {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 10px 24px;
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 18px 22px;
    font-size: 14px;
  }}
  .meta-grid dt {{ color: var(--muted); font-size: 12px; text-transform: uppercase; letter-spacing: 0.05em; margin: 0; }}
  .meta-grid dd {{ margin: 2px 0 8px; font-weight: 600; }}
  .kpis {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 14px; }}
  .kpi {{
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 18px 20px;
  }}
  .kpi .kpi-label {{ font-size: 12px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--muted); }}
  .kpi .kpi-value {{ font-size: 26px; font-weight: 700; margin: 6px 0 4px; }}
  .kpi .kpi-sub {{ font-size: 13px; color: var(--muted); }}
  .kpi .kpi-value.ok {{ color: var(--green); }}
  .advisory {{
    background: linear-gradient(135deg, var(--navy) 0%, #234b7a 100%);
    color: #ffffff;
    border-radius: 14px;
    padding: 24px 28px;
  }}
  .advisory h3 {{ margin: 0 0 14px; font-size: 17px; letter-spacing: 0.3px; }}
  .advisory-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; }}
  .advisory-label {{ font-size: 12px; text-transform: uppercase; letter-spacing: 0.06em; color: #b9cbe2; }}
  .advisory-value {{ font-size: 28px; font-weight: 700; margin: 4px 0 2px; }}
  .advisory-sub {{ font-size: 13px; color: #c8d6e8; }}
  .advisory-note {{ margin: 16px 0 0; font-size: 13px; color: #d7e3f2; border-top: 1px solid rgba(255,255,255,0.18); padding-top: 12px; }}
  table {{
    width: 100%;
    border-collapse: collapse;
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: 12px;
    overflow: hidden;
    font-size: 13.5px;
  }}
  thead th {{
    text-align: left;
    background: #eef2f8;
    color: #3d4d61;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    padding: 10px 12px;
    border-bottom: 1px solid var(--line);
  }}
  tbody td {{ padding: 8px 12px; border-bottom: 1px solid #eef1f6; }}
  tbody tr:nth-child(even) {{ background: #fafcfe; }}
  tbody tr:last-child td {{ border-bottom: none; }}
  td.num {{ font-variant-numeric: tabular-nums; }}
  .badge {{ display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: 12px; font-weight: 600; }}
  .badge-clear {{ background: var(--green-soft); color: var(--green); }}
  .badge-aerodynamic {{ background: var(--amber-soft); color: var(--amber); }}
  .badge-persistent {{ background: var(--red-soft); color: var(--red); }}
  footer {{ margin-top: 32px; font-size: 12.5px; color: var(--muted); border-top: 1px solid var(--line); padding-top: 14px; }}
  code {{ background: #eef2f8; padding: 1px 6px; border-radius: 6px; font-size: 12.5px; }}
</style>
</head>
<body>
<div class="page">

  <header>
    <h1>Project STRATUM</h1>
    <p class="subtitle">Contrail avoidance for Indian air corridors &middot; Step 8 end-to-end corridor flight report</p>
    <div class="badges">
      <span class="pill ok">{PASSING_TESTS} passing tests</span>
      <span class="pill">Real ECMWF ERA5 4D weather</span>
      <span class="pill">{html.escape(origin)} &#8594; {html.escape(destination)} &middot; FL{cruise_fl:.0f}</span>
      <span class="pill">{html.escape(aircraft_type)} &middot; {html.escape(callsign)}</span>
    </div>
  </header>

  <section>
    <h2>Flight metadata</h2>
    <dl class="meta-grid">
      <div><dt>Aircraft</dt><dd>{html.escape(callsign)} (icao24 {html.escape(icao24)}), {html.escape(aircraft_type)}</dd></div>
      <div><dt>Route</dt><dd>{html.escape(origin)} ({origin_lat:.2f}N, {origin_lon:.2f}E) &#8594; {html.escape(destination)} ({destination_lat:.2f}N, {destination_lon:.2f}E)</dd></div>
      <div><dt>Profile</dt><dd>{num_waypoints} cruise waypoints, FL{cruise_fl:.0f}, 6 min spacing</dd></div>
      <div><dt>Departure</dt><dd>{departure.strftime('%Y-%m-%d %H:%M')} UTC ({ist_departure.strftime('%H:%M')} IST)</dd></div>
      <div><dt>Weather data</dt><dd>{html.escape(source_label)}</dd></div>
      <div><dt>Departure scan</dt><dd>Worst-case hour at FL{cruise_fl:.0f}: route-mean RHi {scan_mean_rhi:.2f} over {scan_hours} candidate hours</dd></div>
    </dl>
  </section>

  <section>
    <h2>Key indicators</h2>
    <div class="kpis">
      <div class="kpi">
        <div class="kpi-label">Model status</div>
        <div class="kpi-value ok">Trained &amp; calibrated</div>
        <div class="kpi-sub">LightGBM (monotone constraints) + isotonic regression &middot; {metrics['n_train']} train / {metrics['n_val']} val rows &middot; {metrics['n_masked']} NaN-masked labels</div>
      </div>
      <div class="kpi">
        <div class="kpi-label">Calibration (val Brier)</div>
        <div class="kpi-value">{brier_calibrated:.4f}</div>
        <div class="kpi-sub">raw {brier_raw:.4f} &#8594; calibrated {brier_calibrated:.4f} ({brier_improvement:.1f}% improvement)</div>
      </div>
      <div class="kpi">
        <div class="kpi-label">Persistent segments</div>
        <div class="kpi-value">{result['contrail_persistent_segments']} / {result['total_segments']}</div>
        <div class="kpi-sub">{result['contrail_forming_segments']} SAC-forming &middot; {result['flagged_segments']} flagged for avoidance</div>
      </div>
    </div>
  </section>

  <section>
    <h2>ATC dispatcher advisory</h2>
    <div class="advisory">
      <h3>Contrail avoidance action</h3>
      {advisory_body}
    </div>
  </section>

  <section>
    <h2>Corridor segments (25 waypoints, VIDP &#8594; VABB)</h2>
    <table>
      <thead>
        <tr>
          <th>#</th><th>UTC</th><th>Lat</th><th>Lon</th><th>Temp &deg;C</th>
          <th>RHi</th><th>P(persist)</th><th>Contrail status</th><th>Decision</th>
        </tr>
      </thead>
      <tbody>
        {table_rows}
      </tbody>
    </table>
  </section>

  <footer>
    Generated by <code>scripts/generate_friend_report.py</code> on {generated_at}.
    Data source: real ERA5 analysis, interpolated along the great-circle VIDP&#8594;VABB profile.
    Contrail status: Clear (no SAC formation), Aerodynamic (forms, predicted short-lived),
    Persistent (calibrated P(persist) &#8805; 0.50).
  </footer>

</div>
</body>
</html>
"""


def main() -> int:
    """Run the corridor evaluation and write the HTML report."""
    flight_script = _load_flight_script()
    ds_met, source_label = flight_script._load_met()
    origin, destination = flight_script.ROUTE
    waypoints = great_circle_waypoints(
        AIRPORTS[origin],
        AIRPORTS[destination],
        num_points=flight_script.N_WAYPOINTS,
        fl=flight_script.CRUISE_FL,
    )
    departure, scan_mean_rhi, scan_hours = flight_script._select_departure_time(
        ds_met, waypoints, flight_script.CRUISE_FL
    )
    flight = flight_script._synthesize_flight(departure)
    model, metrics = flight_script._train_baseline()
    result = evaluate_corridor_flight(
        flight, ds_met, model, aircraft_type=flight_script.AIRCRAFT_TYPE
    )

    report_html = _render_html(
        origin=origin,
        destination=destination,
        departure=departure,
        ist_departure=departure + pd.Timedelta(minutes=flight_script.IST_OFFSET_MINUTES),
        cruise_fl=flight_script.CRUISE_FL,
        num_waypoints=flight_script.N_WAYPOINTS,
        source_label=source_label,
        scan_mean_rhi=scan_mean_rhi,
        scan_hours=scan_hours,
        metrics=metrics,
        result=result,
        aircraft_type=flight_script.AIRCRAFT_TYPE,
        callsign=flight_script.CALLSIGN,
        icao24=flight_script.ICAO24,
    )

    output_path = PROJECT_ROOT / HTML_FILENAME
    output_path.write_text(report_html, encoding="utf-8")

    print(f"Report written: {output_path}")
    print(
        f"Corridor: {result['total_segments']} segments | "
        f"{result['contrail_forming_segments']} SAC-forming | "
        f"{result['contrail_persistent_segments']} persistent | "
        f"{len(result['recommended_reroutes'])} advisory event(s) | "
        f"val Brier {metrics['brier_raw']:.4f} -> {metrics['brier_calibrated']:.4f}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
